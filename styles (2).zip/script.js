// --- 1. Product Data & Looping (Shop Page) ---
const products = [
    { id: "ACC-101", name: "Spectra S1 Plus Electric Breast Pump", desc: "Hospital-grade, rechargeable electric pump.", price: 199.99 },
    { id: "ACC-102", name: "Haakaa Manual Breast Pump", desc: "Silicone manual pump to catch letdown.", price: 12.94 },
    { id: "ACC-103", name: "Organic Botanical Nipple Balm", desc: "2oz jar of organic, baby-safe soothing balm.", price: 14.99 },
    { id: "ACC-104", name: "Washable Nursing Pads (8-Pack)", desc: "Reusable, ultra-absorbent bamboo nursing pads.", price: 12.50 },
    { id: "ACC-105", name: "Boppy Nursing Pillow", desc: "Ergonomic support pillow for comfortable feeding.", price: 40.00 },
    { id: "ACC-106", name: "Lactation Support Tea", desc: "Herbal blend to promote healthy milk production.", price: 15.00 },
    { id: "ACC-107", name: "LaVie Lactation Massager", desc: "Relieves clogged ducts and improves milk flow.", price: 30.00 },
    { id: "ACC-108", name: "Breastmilk Storage Bags", desc: "100-count, pre-sterilized leak-proof bags.", price: 16.99 },
    { id: "ACC-109", name: "Silverette Nursing Cups", desc: "Silver nursing cups to protect and soothe.", price: 59.00 },
    { id: "ACC-110", name: "Dr. Brown's Bottle Sterilizer", desc: "Steam sterilizer for bottles and pump parts.", price: 74.99 }
];

function loadProducts() {
    const container = document.getElementById('product-container');
    if (!container) return; // Exit if not on the shop page

    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <h3>${product.name}</h3>
            <p><strong>Description:</strong> ${product.desc}</p>
            <p><strong>Price:</strong> $${product.price.toFixed(2)}</p>
            <button class="cta-button">Add to Cart</button>
        `;
        container.appendChild(card);
    });
}

// --- 2. Form Validation Logic ---
function validateContact(event) {
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    let errors = [];

    if (email === "") errors.push("Email Address is required.");
    if (message === "") errors.push("Message is required.");

    if (errors.length > 0) {
        alert("Contact Form Errors:\n" + errors.join("\n"));
        event.preventDefault(); // Stop form submission
        return false;
    }
    alert("Message sent successfully!");
    return true;
}

function validateCheckout(event) {
    // Shipping Fields
    const shipName = document.getElementById('ship-name').value.trim();
    const shipAddress = document.getElementById('ship-address').value.trim();
    const shipCity = document.getElementById('ship-city').value.trim();
    const shipState = document.getElementById('ship-state').value.trim();
    const shipZip = document.getElementById('ship-zip').value.trim();
    const shipPhone = document.getElementById('ship-phone').value.trim();
    
    // Purchase Fields
    const cardName = document.getElementById('card-name').value.trim();
    const cardNum = document.getElementById('card-num').value.trim();
    const cardExp = document.getElementById('card-exp').value.trim();
    const cardCvv = document.getElementById('card-cvv').value.trim();

    let errors = [];

    if (!shipName || !shipAddress || !shipCity || !shipState || !shipZip || !shipPhone) {
        errors.push("Please fill out all required Shipping fields.");
    }
    
    if (!cardName || !cardNum || !cardExp || !cardCvv) {
        errors.push("Please fill out all required Purchase (Credit Card) fields.");
    }

    if (errors.length > 0) {
        alert("Checkout Errors:\n" + errors.join("\n"));
        event.preventDefault(); // Stop form submission
        return false;
    }
    alert("Order placed successfully!");
    return true;
}

// --- 3. Coupon Logic ---
let baseTotal = 150.00; // Example cart total

function applyCoupon() {
    const code = document.getElementById('coupon-code').value.trim().toUpperCase();
    const msg = document.getElementById('coupon-message');
    const totalDisplay = document.getElementById('order-total');

    if (code === 'NURTURE20') {
        const discountedTotal = baseTotal * 0.80; // 20% discount
        totalDisplay.innerText = discountedTotal.toFixed(2);
        msg.innerText = "Success: 20% discount applied!";
        msg.style.color = "green";
    } else if (code === "") {
        msg.innerText = "Please enter a coupon code.";
        msg.style.color = "red";
    } else {
        totalDisplay.innerText = baseTotal.toFixed(2);
        msg.innerText = "Invalid coupon code.";
        msg.style.color = "red";
    }
}

// Initialize scripts on page load
window.onload = () => {
    loadProducts();
};